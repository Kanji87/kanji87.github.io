<?php

/* ===================================================== */
/* Contact Form
/* ===================================================== */

// This will be where the emails for the contact form will be sent

$config['contact_email'] = 'example@example.com';
$config['subject_line'] = 'Skyline Contact Form';


/* ===================================================== */
/* Mailchimp
/* ===================================================== */

$apikey = "";
$listId = "";


